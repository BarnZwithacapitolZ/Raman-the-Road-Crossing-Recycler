<?xml version="1.0" encoding="UTF-8"?>
<tileset name="city" tilewidth="64" tileheight="64" tilecount="464" columns="29">
 <image source="../images/city.png" width="1899" height="1080"/>
</tileset>
