<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tiles" tilewidth="64" tileheight="64" tilecount="540" columns="27">
 <image source="../images/KENNY/Tilesheet/tilesheet_complete.png" width="1728" height="1280"/>
</tileset>
